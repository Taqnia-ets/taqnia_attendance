package com.example.taqniaattendance.ui.searching

import android.os.Bundle
import android.os.Handler
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.taqniaattendance.AppViewModelFactory
import com.example.taqniaattendance.R
import com.example.taqniaattendance.ServiceLocator
import com.example.taqniaattendance.databinding.ActivityHomeBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class VehiclesActivity : AppCompatActivity() {

    private val viewModel by viewModels<VehiclesViewModel> {
        AppViewModelFactory(ServiceLocator.provideRepository())
    }

    private lateinit var viewDataBinding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureDataBinding()
        setUpVehiclesAdapter()
    }

    private fun configureDataBinding() {
        viewDataBinding = DataBindingUtil.setContentView(this, R.layout.activity_home)
        with (viewDataBinding) {
            viewmodel = viewModel
            lifecycleOwner = this@VehiclesActivity
        }
    }

    private fun subscribeUi() = with(viewModel) {
//        searchState.observe(this@VehiclesActivity, Observer {
//            showSearchState(it)
//        })
//        errorResponse.observe(this@VehiclesActivity, Observer {
//            showMessage(btnSearch, it, ViewType.SNACKBAR.value)
//        })
//        navigation.observe(this@VehiclesActivity, Observer {
//            if (it.withClearStack) goWithFinishAffinity(this@VehiclesActivity, it.destination, null)
//            else  goToActivity(this@VehiclesActivity, it.destination, null)
//        })
//        showLoading.observe(this@VehiclesActivity, Observer { needLoading ->
//            if (needLoading) showLoading() else hideLoading()
//        })
//        tbSearchType.onTabSelected {
//            tvVinOrIdErr.remove()
//            edtVinOrId.hint = when(it?.position) {
//                SEARCH_BY_VIN.value -> getString(R.string.txt_vin_last_6_numbers_hint)
//                SEARCH_BY_ID.value ->  getString(R.string.txt_vehicle_id_hint)
//                else -> ""
//            }
//        }
//        edtVinOrId.apply {
//            onTextChanged { tvVinOrIdErr.remove() }
//            onActionDoneClick { validateInputs() }
//        }
//        btnSearch.onClick { validateInputs() }
//        btnClear.onClick { edtVinOrId.clear() }
    }


    private fun setUpVehiclesAdapter() = with(viewDataBinding.rcvVehicles) {
        adapter = VehiclesAdapter(viewModel)
    }
}
