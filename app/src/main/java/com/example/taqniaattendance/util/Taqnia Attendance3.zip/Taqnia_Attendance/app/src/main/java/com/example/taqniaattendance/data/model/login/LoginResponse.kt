package com.example.taqniaattendance.data.model.login

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class LoginResponse(
    @SerializedName("status")
    @Expose
    val status: String,

    @SerializedName("token")
    @Expose
    val token: String) : Parcelable