package com.example.taqniaattendance.data.model.history

import android.os.Parcelable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Punch(
    @Expose
    @SerializedName("Punch")
    val punch: String?,
    @Expose
    @SerializedName("Status")
    val status: String?,
    @Expose
    @SerializedName("Timestamp")
    val timestamp: String?,
    @Expose
    @SerializedName("TimestampObject")
    val timestampObject: String?
) : Parcelable