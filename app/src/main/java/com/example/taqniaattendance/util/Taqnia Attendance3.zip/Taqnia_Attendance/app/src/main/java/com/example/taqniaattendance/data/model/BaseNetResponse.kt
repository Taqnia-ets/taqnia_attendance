package com.example.taqniaattendance.data.model

import com.example.taqniaattendance.util.Constants
import com.google.gson.annotations.SerializedName

open class BaseNetResponse(@SerializedName("Status")
                              var status: String? = null) {
    fun isSuccessful() : Boolean = !(status.equals(Constants.ErrorConstants.ERROR, true))

}