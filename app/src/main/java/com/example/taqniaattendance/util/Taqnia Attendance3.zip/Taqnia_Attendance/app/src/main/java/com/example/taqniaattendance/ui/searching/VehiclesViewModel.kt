package com.example.taqniaattendance.ui.searching

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations.map
import androidx.lifecycle.ViewModel
import com.example.taqniaattendance.data.model.history.Attendance
import com.example.taqniaattendance.data.model.history.HistoryRequest
import com.example.taqniaattendance.data.model.history.HistoryResponse
import com.example.taqniaattendance.data.model.user.User
import com.example.taqniaattendance.data.source.DataSource
import com.example.taqniaattendance.data.source.Repository
import com.kacst.hsr.data.model.error.AppError

/**
 * Created by Abdulmajeed Alyafey on 6/9/20.
 */
class VehiclesViewModel(
    private val repository: Repository
) : ViewModel() {

    val attendanceHistory = MutableLiveData<List<Attendance?>?>()
    val openHistoryItem = MutableLiveData<Unit>()
    val isEmptyList: LiveData<Boolean> = map(attendanceHistory) {
        it?.isNullOrEmpty()
    }

    init {
        getHistory()
        refreshUser()
    }

    fun getHistory() {
        val historyRequest = HistoryRequest("2020", "6")
        repository.getHistory(historyRequest, object: DataSource.HistoryCallback {
            override fun onGetHistory(historyResponse: HistoryResponse?) {
                val historyAsList = historyResponse?.result?.values?.toList()
                attendanceHistory.postValue(historyAsList)
            }

            override fun onFailure(error: AppError) {

            }
        })
    }

    private fun refreshUser() {
        repository.getSavedUser(object : DataSource.UserCallback {
            override fun onGetUser(user: User?) {
                user?.let { repository.refreshUserInfo(it) }
            }

            override fun onFailure(error: AppError) = Unit
        })
    }
//    fun searchForVehicle(
//        value: String,
//        searchType: Int
//    ) = if (searchType == SEARCH_BY_VIN.value) searchVehicleByVin(value)
//    else searchVehicleById(value)
//
//    private fun searchVehicleByVin(vehicleVin: String) {
//        showLoading.postValue(true)
//        repository.searchVehicleByVin(vehicleVin, object : DataSource.SearchVehicleByVinCallback {
//            override fun onGetVehicles(vehiclesList: List<Vehicle>?) {
//                showLoading.postValue(false)
//                vehicles.postValue(vehiclesList)
//                LogsUtil.printErrorLog("vehiclesResponse", vehiclesList.toGson())
//            }
//            override fun onFailure(error: CustomError) {
//                showLoading.postValue(false)
//                errorResponse.postValue(error)
//            }
//        })
//    }
//
//    private fun searchVehicleById(vehicleId: String) {
//        showLoading.postValue(true)
//        repository.searchVehicleById(vehicleId.toInt(), object : DataSource.SearchVehicleByIdCallback {
//            override fun onGetVehicles(vehiclesList: List<Vehicle>?) {
//                showLoading.postValue(false)
//                vehicles.postValue(vehiclesList)
//            }
//            override fun onFailure(error: CustomError) {
//                showLoading.postValue(false)
//                errorResponse.postValue(error)
//            }
//        })
//    }

//    fun onSelectVehicle(vehicle: Vehicle) {
//
//        showLoading.postValue(true)
//        // Vehicle will be saved upon getting its data.
//        repository.getVehicleById(vehicle.id, object : DataSource.GetVehicleByIdCallback {
//            override fun onGetVehicleById(vehicle: Vehicle?) {
//                showLoading.postValue(false)
//                navigation.postValue(
//                    Navigation(HomeActivity::class.java, withClearStack = true)
//                )
//            }
//            override fun onFailure(error: CustomError) {
//                showLoading.postValue(false)
//                errorResponse.postValue(error)
//            }
//        })
//    }
//
//    fun openVehicleDetailsScreen()
//            = navigation.postValue(Navigation(VehicleFormActivity::class.java))
}