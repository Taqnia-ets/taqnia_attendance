package com.example.taqniaattendance.data.source.local.dao

import androidx.lifecycle.LiveData
import androidx.room.*


@Dao
interface WordDao {
//
//    @Insert(onConflict = OnConflictStrategy.IGNORE)
//    suspend fun insertWord(word: Word)
//
//    @Query("DELETE FROM word_table")
//    suspend fun deleteAll()
//
//    @Delete
//    suspend fun deleteWord(word: Word)
//
//    @Query("SELECT * from word_table ORDER BY word ASC")
//    fun getAllWords(): DataSource.Factory<Int, Word>
}

